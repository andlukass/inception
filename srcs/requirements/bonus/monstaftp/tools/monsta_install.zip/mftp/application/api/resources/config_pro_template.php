<?php
    // BUSINESS EDITION VARIABLES //

    $configPathProfiles = dirname(__FILE__) . "/%s";
    $configPathLicense = dirname(__FILE__) . "/%s";

    define("AUTHENTICATION_FILE_PATH", $configPathProfiles);
    define("MONSTA_LICENSE_PATH", $configPathLicense);
